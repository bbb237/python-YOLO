# facial recognition  > 2024-09-17 1:49am
https://universe.roboflow.com/kalea-sastra-gmail-com/facial-recognition-0autk

Provided by a Roboflow user
License: CC BY 4.0

